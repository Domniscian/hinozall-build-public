package com.domniscian.app

import android.app.Application
import com.domniscian.app.data.DomniscianStore
import com.domniscian.app.instagram.InstagramClient
import com.domniscian.app.instagram.InstagramSessionManager
import com.domniscian.app.instagram.InstagramSessionSlot
import com.domniscian.app.instagram.DirectSyncCoordinator
import com.domniscian.app.notifications.DomniscianNotifier

class DomniscianApplication : Application() {
    val store: DomniscianStore by lazy { DomniscianStore(applicationContext) }
    val sessions: InstagramSessionManager by lazy { InstagramSessionManager(applicationContext) }
    val mainSessions: InstagramSessionManager by lazy { InstagramSessionManager(applicationContext, InstagramSessionSlot.MAIN) }
    val instagram: InstagramClient by lazy { InstagramClient(applicationContext, sessions) }
    val mainInstagram: InstagramClient by lazy { InstagramClient(applicationContext, mainSessions) }
    val directSync: DirectSyncCoordinator by lazy { DirectSyncCoordinator(store, mainInstagram, mainSessions) }
    val notifier: DomniscianNotifier by lazy { DomniscianNotifier(applicationContext) }

    override fun onCreate() {
        super.onCreate()
        notifier.createChannels()
        val preferences = getSharedPreferences("domniscian_preferences", MODE_PRIVATE)
        if (preferences.getInt("diagnostic_cleanup_version", 0) < 13) {
            listOf("login-secondary", "login-main", "login", "login-web").forEach { subsystem ->
                listOf("DOM-511", "DOM-515", "DOM-519", "DOM-520").forEach { code ->
                    store.closeDiagnostic(code, subsystem)
                }
            }
            preferences.edit().putInt("diagnostic_cleanup_version", 13).apply()
        }
        store.refreshAsync()
    }
}
